y={
    "user":"yangjianbo",
    "passwd":"123456"
}
#get方式来取字典的value
c=y.get('user')
# print(c)

for list in y:
    print(list)



# list列表的处理方法
list=[1,2,3,4,5,6]
