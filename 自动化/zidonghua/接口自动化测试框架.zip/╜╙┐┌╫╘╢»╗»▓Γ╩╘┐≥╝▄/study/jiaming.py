a=['jiaming','hongixng','chenxin']
# if 'jiaming' not in a:
#     print('佳明在列表里面')
# else:
#     print('dd')
#
# b={
#     "user":"yangjianbo",
#     "age":18,
#     "room":{"dali":"None"}
# }
# if 'dali' in str(b):
#     print('yyyy')
# else:
#     print('ccccc')

