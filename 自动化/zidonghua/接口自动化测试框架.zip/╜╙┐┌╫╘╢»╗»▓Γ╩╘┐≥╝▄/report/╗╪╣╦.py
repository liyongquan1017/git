
# def 封装函数
def sum():
    a=8+9
    return a

c=sum()
print(c)


if __name__ == '__main__':
    pass